
import com.github.javafaker.Faker;
import java.util.Locale;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Aluno
 */
public class App {
    public static void main(String[] args) {
         Faker random = new Faker (new Locale("pt", "BR"));
         
         
        for(int i = 0; i <=10; i++){ 
        String nomeGerado = random.superhero().name();
        System.out.println("Nome Gerado: " + nomeGerado);}
    }
            
}
